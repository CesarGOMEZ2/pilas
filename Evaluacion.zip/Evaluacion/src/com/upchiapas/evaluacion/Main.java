package com.upchiapas.evaluacion;

import com.upchiapas.evaluacion.models.Acomodo;

public class Main {

    public static void main(String[]args) {

        Acomodo operacion = new Acomodo();

        operacion.EntradaDeDatos();

    }
    
}
